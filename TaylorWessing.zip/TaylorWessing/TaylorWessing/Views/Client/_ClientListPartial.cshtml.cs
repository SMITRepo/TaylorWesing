using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TaylorWessing.Views.Client
{
    public class _ClientListModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
