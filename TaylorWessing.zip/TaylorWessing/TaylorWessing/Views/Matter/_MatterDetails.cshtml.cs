using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TaylorWessing.Views.Matter
{
    public class _MatterDetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
